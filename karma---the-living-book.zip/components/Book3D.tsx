import React, { useState, useRef, useEffect } from 'react';
import { BookContent } from '../types';

interface Book3DProps {
  content: BookContent;
  gestureSignal: { value: number; id: number };
  isGestureActive: boolean;
  onPageTurnComplete: (newPage: number) => void;
  currentPage: number;
}

export const Book3D: React.FC<Book3DProps> = ({ 
  content, 
  gestureSignal, 
  isGestureActive, 
  onPageTurnComplete,
  currentPage 
}) => {
  // Visual state
  const [currentRotation, setCurrentRotation] = useState(0); // 0 to -180
  const [turningDirection, setTurningDirection] = useState<'next' | 'prev' | null>(null);
  
  // Ref to track accumulated gesture for current turn
  const dragAccumulator = useRef(0);
  
  // Initialize or reset when page changes strictly via logic
  useEffect(() => {
    dragAccumulator.current = 0;
    setCurrentRotation(0);
    setTurningDirection(null);
  }, [currentPage]);

  // Handle Gesture Physics
  useEffect(() => {
    if (!isGestureActive) return;
    
    const delta = gestureSignal.value;
    if (delta === 0) return;

    // Sensitivity factor - reduced slightly to feel "heavier" and less jittery
    const sensitivity = 0.4; 
    dragAccumulator.current += delta * sensitivity;

    // Determine direction if not set
    // Start Threshold: How much "pull" is needed to lift the page corner.
    // Increased to 10 to further prevent accidental triggers.
    if (!turningDirection && Math.abs(dragAccumulator.current) > 10) {
      if (dragAccumulator.current < 0 && currentPage < content.pages.length - 1) {
        setTurningDirection('next');
      } else if (dragAccumulator.current > 0 && currentPage > 0) {
        setTurningDirection('prev');
      }
    }

    if (turningDirection === 'next') {
      // Clamp between 0 and -180
      // Dragging left (negative) increases rotation towards -180
      let rot = Math.max(-180, Math.min(0, dragAccumulator.current));
      setCurrentRotation(rot);
    } else if (turningDirection === 'prev') {
      // If prev, we start at -180 (logically) and move to 0.
      let rot = Math.max(-180, Math.min(0, -180 + dragAccumulator.current));
      setCurrentRotation(rot);
    }

  }, [gestureSignal, isGestureActive, currentPage, content.pages.length, turningDirection]);

  // Handle Gesture Release (Snap)
  useEffect(() => {
    if (!isGestureActive && turningDirection) {
      const threshold = -90; // Midpoint
      
      let targetRot = 0;
      let targetPage = currentPage;

      if (turningDirection === 'next') {
        if (currentRotation < threshold) {
          targetRot = -180;
          targetPage = currentPage + 1;
        } else {
          targetRot = 0;
          targetPage = currentPage; // Snap back
        }
      } else {
        // Prev: Current Rotation is calculating from -180 upwards
        if (currentRotation > threshold) {
          targetRot = 0;
          targetPage = currentPage - 1;
        } else {
          targetRot = -180;
          targetPage = currentPage; // Snap back
        }
      }

      // Animate to target
      let animationFrame: number;
      const animateSnap = () => {
        setCurrentRotation(prev => {
          const diff = targetRot - prev;
          if (Math.abs(diff) < 2) {
            if (targetRot === -180 && turningDirection === 'next') {
                onPageTurnComplete(targetPage);
            } else if (targetRot === 0 && turningDirection === 'prev') {
                onPageTurnComplete(targetPage);
            } else {
                // Snapped back
                setTurningDirection(null);
                dragAccumulator.current = 0;
            }
            return targetRot;
          }
          return prev + diff * 0.2; // Faster snap easing
        });
        
        // Continue animation if not reached
        if (Math.abs(targetRot - currentRotation) > 0.5) {
             animationFrame = requestAnimationFrame(animateSnap);
        }
      };
      animateSnap();
      
      return () => cancelAnimationFrame(animationFrame);
    }
  }, [isGestureActive, turningDirection, currentRotation, currentPage, onPageTurnComplete]);

  // RENDER HELPERS
  const renderPageContent = (pageIndex: number, isBack: boolean = false) => {
    if (pageIndex < 0 || pageIndex >= content.pages.length) return null;
    const page = content.pages[pageIndex];

    const isCover = page.type === 'chapter-title';

    return (
      <div className={`w-full h-full p-8 md:p-12 flex flex-col ${isBack ? 'scale-x-[-1]' : ''} bg-[#fdfbf7] text-[#2c2c2c] overflow-hidden relative shadow-inner`}>
        {/* Paper Texture Overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-40 bg-[url('https://www.transparenttextures.com/patterns/cream-paper.png')] mix-blend-multiply"></div>
        
        {/* Page Number */}
        <div className="absolute bottom-6 w-full text-center text-xs font-serif text-gray-500 tracking-widest left-0">
            {page.pageNumber}
        </div>

        {isCover ? (
           <div className="flex-1 flex flex-col items-center justify-center text-center border-4 double border-gray-800 m-4 p-4">
              <h1 className="text-4xl md:text-5xl font-bold font-serif mb-4 text-[#1a1a1a] uppercase tracking-widest">{page.title}</h1>
              <div className="w-16 h-1 bg-red-800 mb-8"></div>
              <p className="text-xl italic text-gray-600 font-serif">{content.author}</p>
           </div>
        ) : (
          <>
            {page.title && (
              <h2 className="text-2xl font-bold font-serif mb-6 text-[#8b4513] border-b border-[#e5e5e5] pb-2">
                {page.title}
              </h2>
            )}
            
            <div className="flex-1 font-serif text-lg leading-relaxed text-justify space-y-4 book-content overflow-y-auto pr-2">
              {page.imageUrl && (
                <div className="float-right w-1/2 ml-4 mb-4 bg-white p-2 shadow-sm transform rotate-1 border border-gray-200">
                  <img src={page.imageUrl} alt="Illustration" className="w-full h-auto sepia-[.3]" />
                  {page.imageCaption && <p className="text-xs text-center mt-2 italic text-gray-500">{page.imageCaption}</p>}
                </div>
              )}
              {page.content.map((para, i) => (
                <p key={i} className="">{para}</p>
              ))}
            </div>
          </>
        )}
        
        {/* Inner Spine Shadow */}
        <div className={`absolute top-0 bottom-0 w-12 pointer-events-none bg-gradient-to-r ${isBack ? 'from-transparent to-[rgba(0,0,0,0.1)] right-0' : 'from-[rgba(0,0,0,0.1)] to-transparent left-0'}`}></div>
      </div>
    );
  };

  // Determine which pages to show
  let leftStaticIndex = currentPage - 1;
  let rightStaticIndex = currentPage;
  let movingPageIndex = -1; // -1 means none

  if (turningDirection === 'next') {
    movingPageIndex = currentPage;
    rightStaticIndex = currentPage + 1;
  } else if (turningDirection === 'prev') {
    movingPageIndex = currentPage - 1;
    leftStaticIndex = currentPage - 2;
  }

  const movingPageRotation = currentRotation; // -180 to 0

  return (
    <div className="relative w-full max-w-5xl h-[80vh] flex justify-center items-center perspective-2000 select-none">
      <style>{`
        .perspective-2000 { perspective: 2000px; }
        .transform-style-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .axis-left { transform-origin: left center; }
      `}</style>

      {/* The Book Container */}
      <div className="relative w-full h-full flex justify-center items-center transform-style-3d">
        
        {/* STATIC LAYER (The pages beneath) */}
        {/* Left Static Page */}
        <div className="absolute w-[45%] h-[90%] left-[5%] top-[5%] bg-[#fdfbf7] shadow-xl border-l border-gray-300 rounded-l-sm overflow-hidden flex z-0">
           {renderPageContent(leftStaticIndex)}
           {/* Thickness simulation for left stack */}
           <div className="absolute right-0 top-0 bottom-0 w-px bg-gray-300"></div>
        </div>

        {/* Right Static Page */}
        <div className="absolute w-[45%] h-[90%] left-[50%] top-[5%] bg-[#fdfbf7] shadow-xl border-r border-gray-300 rounded-r-sm overflow-hidden flex z-0">
           {renderPageContent(rightStaticIndex)}
        </div>

        {/* MOVING PAGE (The flipper) */}
        {movingPageIndex !== -1 && (
          <div 
            className="absolute w-[45%] h-[90%] left-[50%] top-[5%] transform-style-3d axis-left z-20 will-change-transform"
            style={{ 
              transform: `rotateY(${movingPageRotation}deg)`,
              // Add a subtle Z translate to prevent Z-fighting at 0 or -180
              marginLeft: movingPageRotation < -90 ? '0px' : '-1px' 
            }}
          >
            {/* Front of the moving page (Visible when rot > -90) */}
            <div className="absolute inset-0 backface-hidden bg-[#fdfbf7] rounded-r-sm shadow-md overflow-hidden">
                {renderPageContent(movingPageIndex)}
                {/* Dynamic Shine/Shadow based on curl */}
                <div 
                    className="absolute inset-0 pointer-events-none"
                    style={{
                        background: `linear-gradient(to right, rgba(0,0,0,${Math.abs(movingPageRotation)/600}), transparent)`
                    }}
                />
            </div>

            {/* Back of the moving page (Visible when rot < -90) */}
            <div 
                className="absolute inset-0 backface-hidden bg-[#fdfbf7] rounded-l-sm shadow-md overflow-hidden"
                style={{ transform: 'rotateY(180deg)' }}
            >
                {renderPageContent(movingPageIndex, true)}
                 {/* Dynamic Shine/Shadow for back */}
                 <div 
                    className="absolute inset-0 pointer-events-none"
                    style={{
                        background: `linear-gradient(to left, rgba(0,0,0,${(180 - Math.abs(movingPageRotation))/600}), transparent)`
                    }}
                />
            </div>
          </div>
        )}

        {/* Spine visual */}
        <div className="absolute left-1/2 top-[4%] bottom-[4%] w-8 -ml-4 rounded-lg bg-[#3e2723] z-[-1] shadow-2xl transform translate-z-[-5px]"></div>

      </div>
    </div>
  );
};